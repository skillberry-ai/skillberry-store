---
name: sample_skill_complex_dep
description: A sample skill with complex tool dependencies for testing
---

# Sample Skill with Complex Dependencies

This skill demonstrates complex dependency relationships between tools.

## Tools

- **calc**: Main calculator function that delegates to other tools
- **calc_add_subtract**: Handles addition and subtraction operations
- **multiply**: Multiplies two numbers
- **add**: Adds two numbers
- **subtract**: Subtracts two numbers

## Dependencies

The tools have the following dependency structure:
- calc depends on calc_add_subtract and multiply
- calc_add_subtract depends on add and subtract
- multiply depends on add and subtract
